SELECT c.city_name, percentile_cont(0.9) WITHIN GROUP (ORDER BY t.actual_eta - t.predicted_eta) AS percentile_90
FROM trips as t
LEFT JOIN cities as c
ON t.city_id = c.city_id
WHERE t.request_at > (CURRENT_DATE - INTERVAL '30 days')
AND (c.city_name = 'Qarth' OR c.city_name = 'Meereen')
GROUP BY c.city_name
