CREATE TYPE status_type AS ENUM ('completed', 'cancelled_by_driver', 'cancelled_by_client');
CREATE TABLE trips (
    id int,
    client_id int,
    driver_id int,
    city_id int,
    client_rating int,
    driver_rating int,
    request_at timestamptz,
    predicted_eta int,
    actual_eta int,
    status status_type
);
INSERT INTO trips VALUES (1, 11, 111, 1111, 7, 9, '2016-01-14 19:10:25-00', 600, 650, 'completed');
INSERT INTO trips VALUES (2, 12, 112, 1112, 10, 2, '2016-01-14 19:10:27-00', 200, 190, 'completed');
INSERT INTO trips VALUES (3, 13, 113, 1111, 8, 7, '2016-01-14 19:10:29-00', 470, 440, 'completed');
INSERT INTO trips VALUES (4, 13, 113, 1112, 8, 7, '2016-01-14 19:10:29-00', 470, 420, 'completed');
INSERT INTO trips VALUES (1, 11, 111, 1111, 7, 9, '2016-01-14 19:10:25-00', 600, 630, 'completed');
INSERT INTO trips VALUES (2, 12, 112, 1112, 10, 2, '2016-01-07 19:10:27-00', 202, 196, 'completed');
INSERT INTO trips VALUES (3, 13, 113, 1111, 8, 7, '2016-01-07 19:10:29-00', 370, 440, 'completed');
INSERT INTO trips VALUES (4, 13, 113, 1112, 8, 7, '2016-01-07 19:10:29-00', 270, 420, 'completed');
INSERT INTO trips VALUES (1, 11, 111, 1111, 7, 9, '2016-01-07 19:10:25-00', 605, 650, 'completed');
INSERT INTO trips VALUES (2, 12, 112, 1112, 10, 2, '2016-01-07 19:10:27-00', 240, 190, 'completed');

CREATE TABLE cities (
    city_id int,
    city_name varchar(255)
);
INSERT INTO cities VALUES (1111, 'Qarth');
INSERT INTO cities VALUES (1112, 'Meereen');
INSERT INTO cities VALUES (1113, 'Chicago');

CREATE TYPE event_type AS ENUM ('sign_up_success', 'attempted_sign_up', 'sign_up_failure');
CREATE TABLE events (
    device_id int,
    rider_id int,
    city_id int,
    event_name event_type,
    _ts timestamptz
);
INSERT INTO events VALUES (11111, 12, 1111, 'sign_up_success', '2016-01-04 19:10:29-00');
INSERT INTO events VALUES (11112, 11, 1111, 'sign_up_success', '2016-01-03 19:10:29-00');
INSERT INTO events VALUES (11113, 13, 1112, 'sign_up_success', '2016-01-06 19:10:29-00');
INSERT INTO events VALUES (11114, 11, 1112, 'sign_up_success', '2016-01-09 19:10:29-00');
