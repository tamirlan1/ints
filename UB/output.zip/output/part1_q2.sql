SELECT city_name, day_of_the_week, max(valid_trip)*100::decimal/count(*) as good_signup_percent
FROM
(SELECT c.city_name as city_name, 
    EXTRACT(DOW FROM e._ts) as day_of_the_week,
    CASE WHEN t.request_at - e._ts <= INTERVAL '168 hours' THEN 1 ELSE 0 END as valid_trip,
    e._ts
FROM trips as t
JOIN cities as c
ON t.city_id = c.city_id
JOIN events as e
ON t.client_id = e.rider_id

WHERE event_name = 'sign_up_success'
AND (c.city_name = 'Qarth' OR c.city_name = 'Meereen')
AND EXTRACT(YEAR FROM e._ts) = 2016
AND EXTRACT(WEEK FROM e._ts) = 1
AND t.status = 'completed') as t

GROUP BY city_name, day_of_the_week, _ts
